# EMBER sticker pack

BONFIRE testnet Round 2. The stickers were generated after backing closed at 17:43:21 UTC on November 9, 2026.

Nominated creator and submitter: bonfire-meraj-maker1.testnet.

## Free use

These six stickers are free for anyone to use, copy, share, and adapt.

## Tools

OpenAI ImageGen generated the six transparent PNGs using BONFIRE's existing idle mascot artwork as a visual reference. Pillow checked the PNG alpha channels and readability at 64 px on light and dark backgrounds. Python's zipfile module packaged the six original PNGs and this note.

## ImageGen prompts

Each call used the shared prompt below followed by the scene for that file. Transparent background was enabled.

Reference image: the BONFIRE repository file apps/web/card-assets/mascot-idle.png.

### Shared prompt

~~~text
Use case: illustration-story.
Asset type: one square transparent PNG chat sticker for BONFIRE's EMBER mascot, legible at 64 pixels.
Input image 1 is the identity and rendering reference for EMBER. Draw the same character in a fresh full-body pose. Keep the same left-swept layered flame crest, rounded molten-orange body, dark cracked lava base, golden eyes, cheek freckles, mitten hands, short boots, dark brown outlines and rich cel-shaded orange and gold.
Draw one compact, cohesive sticker vignette, with EMBER the largest element and the action readable by silhouette. Center it with even breathing room and keep all props within the frame. Keep details bold and sparse. The canvas outside the subject and any stated props must be truly transparent alpha. No border, text, watermark, patterned backdrop or scenic background.
~~~

### Scenes

#### 01-stoke-the-fire.png

~~~text
Scene: Show EMBER kneeling in three-quarter profile, both hands gripping a short iron fire poker aimed into a compact pile of glowing red coals between two thick blackened logs. The eyes follow the tip and the pose shows focused effort. No large flame on the log pile, so EMBER stays unmistakable.
~~~

#### 02-roast-a-marshmallow.png

~~~text
Scene: Show EMBER sitting cross-legged and holding one thin diagonal roasting stick with one big, visibly toasted ivory marshmallow at its end. Keep the treat separate from the body silhouette and make it unmistakable. EMBER watches it with an eager grin. Use only a few glowing coals beneath the marshmallow.
~~~

#### 03-light-the-way.png

~~~text
Scene: Show EMBER taking a purposeful step in three-quarter view, holding a squat antique bronze camping lantern by its handle low and forward beside the body. The lantern has a pale yellow center and a few thick frame bars so it reads at small sizes. The other arm swings back, with no trail or scenery.
~~~

#### 04-wave-hello.png

~~~text
Scene: Show EMBER leaning toward the viewer with a broad friendly grin, one open mitten palm facing outward, fingertips above the eyes and clear of the flame crest. The other hand rests low near the hip. Add just two short wave motion arcs. Both feet stay grounded. No props or sparks.
~~~

#### 05-warm-up.png

~~~text
Scene: Show EMBER seated snugly, holding one big deep teal enamel camping mug in both hands, with one bold curling steam ribbon rising from the rim against the transparent space next to the face. EMBER's half-lidded content expression and the hands cupped around the mug should read immediately. No other props.
~~~

#### 06-work-accepted.png

~~~text
Scene: Show EMBER leaning over a large cream work order and pressing a chunky dark wooden rubber stamp onto it with one hand. The paper tilts toward the viewer, bearing one clearly visible oversized forest-green check mark beside the stamp. Use a compact confident pose with the face visible above the sheet. No writing, letters or numbers.
~~~
